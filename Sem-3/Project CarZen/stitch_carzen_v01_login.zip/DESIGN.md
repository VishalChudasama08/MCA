---
name: CarZen Intelligence
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0d0e0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c2c6d8'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8c90a1'
  outline-variant: '#424656'
  surface-tint: '#b3c5ff'
  primary: '#b3c5ff'
  on-primary: '#002b75'
  primary-container: '#0066ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#0054d6'
  secondary: '#c8c6c5'
  on-secondary: '#313030'
  secondary-container: '#4a4949'
  on-secondary-container: '#bab8b7'
  tertiary: '#c9c6c5'
  on-tertiary: '#313030'
  tertiary-container: '#737171'
  on-tertiary-container: '#faf7f6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c9c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474646'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-metric:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
---

## Brand & Style

The design system is engineered to evoke the precision and luxury of high-end automotive engineering. It targets a sophisticated audience that values technological prowess and seamless transactions. 

The aesthetic is **Corporate Modern** with a **Tactile** edge, leaning into the "Digital Cockpit" feel. It prioritizes high-density information presented with extreme clarity. The visual narrative focuses on "Precision over Decoration," utilizing generous negative space, crisp lines, and subtle depth to guide the user through the car-buying journey. 

Every interaction should feel deliberate and high-performance, mirroring the haptic feedback of a premium vehicle dashboard.

## Colors

The palette is anchored in a deep, cinematic dark mode that creates a "showroom" effect for vehicle imagery.

- **Primary (#0066FF):** "Electric Velocity." A high-energy blue used exclusively for primary calls to action, active states, and critical paths.
- **Surface & Backgrounds:** We use a tiered dark system. `#0A0A0A` is the base canvas (Pitch), while `#121212` (Charcoal) is used for elevated containers and cards.
- **Typography:** `#FFFFFF` is reserved for headings to ensure maximum impact, while `#E0E0E0` provides a softer, legible contrast for body copy and metadata.
- **Accents:** Use subtle `#1E1E1E` for borders to maintain a low-contrast, premium "ghost" appearance.

## Typography

This design system utilizes **Inter** for its systematic, utilitarian precision. It bridges the gap between technical data and lifestyle editorial.

- **Headlines:** Use tight letter-spacing and semi-bold/bold weights to create a sense of authority. 
- **Data Display:** For technical specs (HP, 0-60 mph, Price), use the `mono-metric` style to ensure numbers align and feel like a digital odometer.
- **Labels:** Small-scale uppercase labels should be used for categories and technical tags to maintain the "instrument cluster" aesthetic.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a hard 8px rhythmic base. 

- **Desktop:** A 12-column grid with wide 48px margins to allow the "product-as-hero" to breathe.
- **Mobile:** A 4-column grid with 16px margins. 
- **Rhythm:** Use increments of 8px for vertical spacing (e.g., 16, 32, 64) to maintain mathematical harmony. 
- **Alignment:** All technical data points should be left-aligned for rapid scanning, while hero sections can utilize centered layouts for cinematic impact.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** rather than heavy shadows. 

- **Level 0 (Background):** `#0A0A0A` — The base floor.
- **Level 1 (Cards/Containers):** `#121212` — Subtle elevation.
- **Level 2 (Modals/Popovers):** `#1E1E1E` — Using a 1px solid border of `#333333` to define edges.
- **Shadows:** When used, shadows should be "Ambient" — ultra-soft, using `#000000` at 40% opacity with a large 30px blur and 0px spread to simulate a car under studio lighting.
- **Gradients:** Use very subtle linear gradients (Top: `#1A1A1A` to Bottom: `#121212`) on interactive surfaces to give them a machined, tactile feel.

## Shapes

The shape language reflects modern automotive surfacing — aerodynamic and smooth but purposeful.

- **Standard Radius (8px):** Used for standard buttons and small components.
- **Container Radius (12px - 16px):** Used for input fields and primary cards to create a soft, approachable tech feel.
- **Circular/Pill:** Reserved for status indicators (e.g., "In Stock") and icon buttons to contrast against the structured grid.

## Components

- **Buttons:** Primary buttons use a solid `#0066FF` fill with white text. Secondary buttons use a ghost style with a 1px `#333333` border and white text, shifting to a subtle grey fill on hover.
- **Input Fields:** 16px rounded corners with a `#121212` fill. On focus, the border transitions to `#0066FF` with a soft blue outer glow.
- **Cards:** No external borders. Use background color differentiation (`#121212`) and subtle internal padding (24px) to group content.
- **Chips/Tags:** Small, high-contrast badges for "New Arrival" or "Electric." Use `label-caps` typography.
- **Spec List:** A vertical list of key-value pairs (e.g., Engine: V8) using `mono-metric` for values to emphasize technical accuracy.
- **Interactive Gauges:** Custom circular sliders or progress bars in Electric Blue to represent battery life or performance metrics.